<?php
    // Database connection details
    // Replace 'your-rds-endpoint.amazonaws.com' with your actual RDS endpoint
    $host = 'mysqldb.ceqtnqeanztw.us-east-1.rds.amazonaws.com';
    $user = 'admin'; // Replace with your RDS database username
    $password = 'Mayur002#'; // Replace with your RDS database password
    $database = 'mayurdb'; // Replace with your RDS database name

    // Connect to database with a try/catch statement
    // If the connection is not successful, display the error message via database_error.php
    // The PDOException class represents the error raised by PDO
    // The PDO error is stored in the variable $e
    // The PDO error is returned as a string via the getMessage() function
    try
    {
        $conn = new PDO("mysql:host=$host;dbname=$database", $user, $password);
        // Set the PDO error mode to exception for better error handling
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        $error_message = $e->getMessage();
        include('../view/database_error.php');
        exit();
    }
?>