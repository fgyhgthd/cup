<?php
	header('location: view/login_form.php');
?>