install by creating database gorgeous_cupcakes on mysql localhost
import gorgeous_cupcakes_v1.sql file into new database

run by visiting http://localhost/gorgeous_cupcakes

Database has one user already defined:
Username: admin
Password: password
